import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  currentYear: number = new Date().getFullYear();
  constructor(private router: Router, private fb: FormBuilder, private commonService: CommonService, private masterService: MasterService) {
    localStorage.removeItem('user');
   }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  login() {
    if (this.loginForm.valid) {
      this.masterService.authenticateUser(this.loginForm.value).subscribe((data: any) => {
        if (data && data.token) {
          localStorage.setItem('user', JSON.stringify(data));
          this.masterService.getMenuList(data.roleId).subscribe((res:any)=>{
            this.commonService.originalMenuList$.next(res);
            if(res.length>0){
            this.router.navigate([`/nav/${res[0].children[0].route}`]);
            this.commonService.setMenuList(res);
          } else {
            this.commonService.showMessage('No menu found for this user', 'error');
          }
            })
        }
      }, err => {
        this.commonService.showMessage('Please enter valid credentials', 'error');
      });

    } else {
      this.loginForm.markAllAsTouched();
    }
  }
}
