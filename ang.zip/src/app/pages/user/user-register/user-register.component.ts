import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})

export class UserRegisterComponent {
  showTable: boolean = true;
  userRegisterForm!: FormGroup;
  userRegisterList: any[] = [];
  dataSource: any[] = [];
  DepartmentList:any=[];
  roleList:any=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.initUserRegisterForm();
    this.getuserRegisterList();
    this.getdepartmentList();
    this.getroleList();
  }

  initUserRegisterForm() {
    this.userRegisterForm = this.fb.group({
      userId: new FormControl<number>(0, { nonNullable: true }),
      userName: new FormControl<string>('', Validators.required),
      firstName: new FormControl<string>('', Validators.required),
      lastName: new FormControl<string>('', Validators.required),
      emailId: new FormControl<string>('', Validators.required),
      password: new FormControl<string>('', Validators.required),
      confirmPassword: new FormControl<string>('', Validators.required),
      deptId: new FormControl<string>('', Validators.required),
      roleId: new FormControl<string>('', Validators.required), 
      contactNo: new FormControl<string>('', { nonNullable: true }),
      empCode: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    }, {
       validators: this.checkMatchingPasswords('password', 'confirmPassword') 
      });
  }
  checkMatchingPasswords(passwordKey: string, passwordConfirmationKey: string):any {
    return (group: FormGroup) => {
      const passwordInput = group.controls[passwordKey];
      const passwordConfirmationInput = group.controls[passwordConfirmationKey];
      if (passwordInput.value !== passwordConfirmationInput.value) {
        if (passwordConfirmationInput.value) {
          this.userRegisterForm.get('confirmPassword')?.setErrors({ mismatch: true, });
        } else {
          this.userRegisterForm.get('confirmPassword')?.setValidators(Validators.required);
        }
      } else {
        return passwordConfirmationInput.setErrors(null);
      }
    };
  }

  getuserRegisterList() {
    this.masterService.getUserList().subscribe((data: any) => {
      this.userRegisterList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.userRegisterList));
    });
  }

  checkUser(type:string, control:string) {
    if(this.userRegisterForm.get(control)?.value !== '') {
    this.masterService.checkUser(type,this.userRegisterForm.get(control)?.value).subscribe((data: any) => {
      if (data) {
        this.userRegisterForm?.get(control)?.setErrors({ incorrect: true });
      } else {
        this.userRegisterForm.get(control)?.clearValidators();
        this.userRegisterForm.get(control)?.setErrors({required:true});
        this.userRegisterForm.get(control)?.updateValueAndValidity();
      }
    });
  }
  }

  getdepartmentList() {
    this.masterService.getDepartmentList().subscribe((data: any) => {
      this.DepartmentList = data;
    });
  }

  getroleList() {
    this.masterService.getRoleList().subscribe((data: any) => {
      this.roleList = data;
    });
  }

  get isEdit() {
    return this.userRegisterForm.controls['userId'].value !== 0;
  }

  saveuserRegisterDetail() {
    if (this.userRegisterForm.valid) {
      this.masterService
        .saveUserDetail(this.userRegisterForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getuserRegisterList();
            this.showTable = true;
            !this.isEdit? this.commonService.showMessage('User added successfully','success'): this.commonService.showMessage('User updated successfully','success');
            this.userRegisterForm.reset();
          }
        });
    } else {
      this.userRegisterForm.markAllAsTouched();
    }
  }

  pageChanged(event: any[]) {
    this.userRegisterList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.userRegisterForm.patchValue(obj);
    this.showTable = false;
  }

  cancel() {
    this.showTable = true;
    this.userRegisterForm.reset();
  }

  reset() {
    this.userRegisterForm.reset();
  }
}
