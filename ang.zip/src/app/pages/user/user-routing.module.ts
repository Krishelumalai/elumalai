import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentRegisterComponent } from './department-register/department-register.component';
import { RolePermissionComponent } from './role-permission/role-permission.component';
import { RoleRegisterComponent } from './role-register/role-register.component';
import { UserRegisterComponent } from './user-register/user-register.component';

const routes: Routes = [
  {
    path: 'user',
    component: UserRegisterComponent,
  },
  {
    path: 'department',
    component: DepartmentRegisterComponent,
  },
  {
    path: 'role-permission',
    component: RolePermissionComponent,
  },
  {
    path: 'role',
    component: RoleRegisterComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
