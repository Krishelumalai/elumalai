import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-department-register',
  templateUrl: './department-register.component.html',
  styleUrls: ['./department-register.component.scss'],
})
export class DepartmentRegisterComponent implements OnInit {
  showTable: boolean = true;
  departmentForm!: FormGroup;
  departmentList: any[] = [
  ];
  dataSource: any[] = [];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.initDepartmentForm();
    this.getDepartmentList();
  }

  initDepartmentForm() {
    this.departmentForm = this.fb.group({
      deptId: new FormControl<number>(0, { nonNullable: true }),
      deptName: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }
  getDepartmentList() {
    this.masterService.getDepartmentList().subscribe((data: any) => {
      this.departmentList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.departmentList));
    });
  }

  get isEdit() {
    return this.departmentForm.controls['deptId'].value !== 0;
  }

  saveDepartmentDetail() {
    if (this.departmentForm.valid) {
      this.masterService
        .saveDepartmentDetail(this.departmentForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getDepartmentList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Department added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Department updated successfully',
                Messages.SUCCESS
              );
            this.departmentForm.reset();
          }
        });
    } else {
      this.departmentForm.markAllAsTouched();
    }
  }
  pageChanged(event: any[]) {
    this.departmentList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.departmentForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.departmentForm.reset();
  }

  reset() {
    this.departmentForm.reset();
  }
}
