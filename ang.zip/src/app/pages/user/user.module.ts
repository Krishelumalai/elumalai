import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserRegisterComponent } from './user-register/user-register.component';
import { DepartmentRegisterComponent } from './department-register/department-register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoleRegisterComponent } from './role-register/role-register.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { RolePermissionComponent } from './role-permission/role-permission.component';


@NgModule({
  declarations: [
    UserRegisterComponent,
    DepartmentRegisterComponent,
    RoleRegisterComponent,
    RolePermissionComponent,
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ]
})
export class UserModule { }
