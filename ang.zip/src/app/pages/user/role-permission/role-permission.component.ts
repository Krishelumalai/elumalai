import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-role-permission',
  templateUrl: './role-permission.component.html',
  styleUrls: ['./role-permission.component.scss'],
})
export class RolePermissionComponent {
  showTable: boolean = true;
  rolePermissionList :any;
  roleList: any[] = [];
  dataSource: any[] = [];
  roleId: number = 0;
  finalMenuList: any[] = [];
  menuList: any[] = [];
  allScreensList: any;

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void { 
    this.getRoleList();
    // this.arrangeMenuList();
    // this.getRolePermissionList();
  }

  getRoleList() {
    this.masterService.getRoleList().subscribe((data: any) => {
      this.roleList = data;
    });
  }
  getAllScreensList() {
    this.masterService.getAllScreensList().subscribe((data: any) => {
      this.menuList = data;

      this.arrangeMenuList();
    });
  }
  getRolePermissionList() {
    this.masterService
      .getRoleScreenDeatails(this.roleId)
      .subscribe((data: any) => {
        this.rolePermissionList = data;
        this.finalMenuList =[];
        if(this.rolePermissionList.screenAccessLst){
        this.getAllScreensList();
        }
      });
  }
  arrangeMenuList() {
    this.menuList.forEach((menu) => {
      if (menu.children.length > 0) {
        menu.children.forEach((child: any) => {
          
          this.finalMenuList.push({
            screenId: child.subMenuId,
            screenName: child.menuName,
            viewAccess: this.rolePermissionList.screenAccessLst.find((f:any)=>f.screenId==child.subMenuId)?.viewAccess,
            createAccess: true,
            editAccess: true,
            deleteAccess: true,
            active: true,
          });
        });
      }
    });
    this.dataSource = JSON.parse(JSON.stringify(this.finalMenuList));
  }

  saveRolePermissionDetail() {
    if (this.roleId > 0) {
      const data = {
        roleId: this.roleId,
        screenAccessLst: this.finalMenuList,
        loggedIn: this.masterService.loggedInUserId(),
      };
      this.masterService.saveRoleScreenAccess(data).subscribe((resp: any) => {
        if (resp) {
          this.roleId =0;
          this.finalMenuList =[];
          this.commonService.showMessage(
            'Role Permission updated successfully',
            Messages.SUCCESS
          ); 
        }
      });
    }  
  }
  updateAccess(event: any, type: string, index: number) {
    this.finalMenuList[index][type] = event.target.checked;
  }
  pageChanged(event: any[]) {
    this.finalMenuList = event;
    this.cdr.detectChanges();
  }

  cancel() {
    this.showTable = true; 
  }

  reset() { 
  }
}
