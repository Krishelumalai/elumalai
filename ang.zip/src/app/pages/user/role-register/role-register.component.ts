import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-role-register',
  templateUrl: './role-register.component.html',
  styleUrls: ['./role-register.component.scss']
})
export class RoleRegisterComponent implements OnInit {
  showTable: boolean = true;
  roleForm!: FormGroup;
  roleList: any[] = [ 
  ];
dataSource: any[] = [];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initRoleForm();
    this.getRoleList();
  }

  initRoleForm() {
    this.roleForm = this.fb.group({
      roleId: new FormControl<number>(0, { nonNullable: true }),
      roleName: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }
  getRoleList() {
    this.masterService.getRoleList().subscribe((data: any) => {
      this.roleList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.roleList));
    });
  }

  get isEdit() {
    return this.roleForm.controls['roleId'].value !== 0;
  }

  saveRoleDetail() {
    if (this.roleForm.valid) {
      this.masterService
        .saveRoleDetail(this.roleForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getRoleList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                  'Role added successfully',
                  Messages.SUCCESS
                )
              : this.commonService.showMessage(
                  'Role updated successfully',
                  Messages.SUCCESS
                );
            this.roleForm.reset();
          }
        });
    } else {
      this.roleForm.markAllAsTouched();
    }
  }
  pageChanged(event: any[]) {
    this.roleList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.roleForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.roleForm.reset();
  }

  reset() {
    this.roleForm.reset();
  }
}
