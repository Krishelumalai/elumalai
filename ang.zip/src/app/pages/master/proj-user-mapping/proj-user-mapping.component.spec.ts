import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjUserMappingComponent } from './proj-user-mapping.component';

describe('ProjUserMappingComponent', () => {
  let component: ProjUserMappingComponent;
  let fixture: ComponentFixture<ProjUserMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjUserMappingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjUserMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
