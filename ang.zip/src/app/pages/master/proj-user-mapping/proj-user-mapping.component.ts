import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-proj-user-mapping',
  templateUrl: './proj-user-mapping.component.html',
  styleUrls: ['./proj-user-mapping.component.scss']
})
export class ProjUserMappingComponent {
  showTable = true;
  projUserMapForm!: FormGroup;

  projUserMapList:any[] = [];
  projectList:any[]=[];
  userList:any[]=[];
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initProjUserMappingForm();
    this.getProjectList();
    this.getUserList();
    this.getProjUserMappingList();
  }


  initProjUserMappingForm() {
    this.projUserMapForm = this.fb.group({
      projectMapId: new FormControl<number>(0, { nonNullable: true }),
      intProjId: new FormControl<number|null>(null, Validators.required),
      userId: new FormControl<number|null>(null, Validators.required),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }
  getProjectList() {
    this.masterService.getProjectList().subscribe((data: any) => {
      this.projectList = data;
    })
  }
  getUserList() {
    this.masterService.getUserList().subscribe((data: any) => {
      this.userList = data;
    })
  }

  getProjUserMappingList() {
    this.masterService.getProjUserMappingList().subscribe((data: any) => {
      this.projUserMapList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.projUserMapList));
    })
  }

  get isEdit() {
    return this.projUserMapForm.controls['projectMapId'].value !== 0;
  }

  saveProjUserMappingDetail() {
    if (this.projUserMapForm.valid) {
      this.masterService
        .saveProjUserMappingDetail(this.projUserMapForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getProjUserMappingList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Project User Mapping added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Project User Mapping updated successfully',
                Messages.SUCCESS
              );
            this.projUserMapForm.reset();
          }
        });
    } else {
      this.projUserMapForm.markAllAsTouched();
    }
  }
 

  pageChanged(event: any[]) {
    this.projUserMapList = event; 
  }

  editData(obj: any) {
    this.projUserMapForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.projUserMapForm.reset();
  }

  reset() {
    this.projUserMapForm.reset();
  }

}

