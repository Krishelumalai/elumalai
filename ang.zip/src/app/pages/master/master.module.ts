import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterRoutingModule } from './master-routing.module';
import { AgeComponent } from './age/age.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { KnowAboutUsComponent } from './know-about-us/know-about-us.component';
import { OccupationComponent } from './occupation/occupation.component';
import { PreferredUnitsComponent } from './preferred-units/preferred-units.component';
import { PreferredBudgetRangeComponent } from './preferred-budget-range/preferred-budget-range.component';
import { PreferredSizeComponent } from './preferred-size/preferred-size.component';
import { PurposeOfPurchaseComponent } from './purpose-of-purchase/purpose-of-purchase.component';
import { ProjectComponent } from './project/project.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProjUserMappingComponent } from './proj-user-mapping/proj-user-mapping.component';
import { StatusComponent } from './status/status.component';


@NgModule({
  declarations: [
    AgeComponent,
    KnowAboutUsComponent,
    OccupationComponent,
    PreferredUnitsComponent,
    PreferredBudgetRangeComponent,
    PreferredSizeComponent,
    PurposeOfPurchaseComponent,
    ProjectComponent,
    ProjUserMappingComponent,
    StatusComponent
  ],
  imports: [
    CommonModule,
    MasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ]
})
export class MasterModule { }
