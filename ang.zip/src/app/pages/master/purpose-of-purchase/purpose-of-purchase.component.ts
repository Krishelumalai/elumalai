import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-purpose-of-purchase',
  templateUrl: './purpose-of-purchase.component.html',
  styleUrls: ['./purpose-of-purchase.component.scss']
})
export class PurposeOfPurchaseComponent {
  showTable = true;
  purposeOfPurchaseForm!: FormGroup;

  purposeOfPurchaseList = [
    {
      "purposeOfPurchaseID": 1,
      "name": "<50 L",
      "description": " "
    }
  ]
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initPurposeOfPurchaseForm();
    this.getPurposeOfPurchaseList();
  }


  initPurposeOfPurchaseForm() {
    this.purposeOfPurchaseForm = this.fb.group({
      purposeId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getPurposeOfPurchaseList() {
    this.masterService.getPurposeOfPurchaseList().subscribe((data: any) => {
      this.purposeOfPurchaseList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.purposeOfPurchaseList));
    })
  }

  get isEdit() {
    return this.purposeOfPurchaseForm.controls['purposeId'].value !== 0;
  }

  savePurposeOfPurchaseDetail() {
    if (this.purposeOfPurchaseForm.valid) {
      this.masterService
        .savePurposeOfPurchaseDetail(this.purposeOfPurchaseForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getPurposeOfPurchaseList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Purpose of Purchase added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Purpose of Purchase updated successfully',
                Messages.SUCCESS
              );
            this.purposeOfPurchaseForm.reset();
          }
        });
    } else {
      this.purposeOfPurchaseForm.markAllAsTouched();
    }
  }
 

  pageChanged(event: any[]) {
    this.purposeOfPurchaseList = event; 
  }

  editData(obj: any) {
    this.purposeOfPurchaseForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.purposeOfPurchaseForm.reset();
  }

  reset() {
    this.purposeOfPurchaseForm.reset();
  }
}
