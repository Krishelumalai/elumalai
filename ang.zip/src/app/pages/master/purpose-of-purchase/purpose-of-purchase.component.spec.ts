import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurposeOfPurchaseComponent } from './purpose-of-purchase.component';

describe('PurposeOfPurchaseComponent', () => {
  let component: PurposeOfPurchaseComponent;
  let fixture: ComponentFixture<PurposeOfPurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurposeOfPurchaseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurposeOfPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
