import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgeComponent } from './age/age.component';
import { KnowAboutUsComponent } from './know-about-us/know-about-us.component';
import { OccupationComponent } from './occupation/occupation.component';
import { PreferredBudgetRangeComponent } from './preferred-budget-range/preferred-budget-range.component';
import { PreferredUnitsComponent } from './preferred-units/preferred-units.component';
import { PreferredSizeComponent } from './preferred-size/preferred-size.component';
import { PurposeOfPurchaseComponent } from './purpose-of-purchase/purpose-of-purchase.component';
import { ProjectComponent } from './project/project.component';
import { ProjUserMappingComponent } from './proj-user-mapping/proj-user-mapping.component';
import { StatusComponent } from './status/status.component';

const routes: Routes = [
  {
    path:'age',
    component: AgeComponent
  },
  {
    path:'know-about-us',
    component: KnowAboutUsComponent
  },
  {
    path:'occupation',
    component: OccupationComponent
  },
  {
    path:'preferred-units',
    component: PreferredUnitsComponent
  },
  {
    path:'preferred-budget-range',
    component: PreferredBudgetRangeComponent
  },
  {
    path:'preferred-size',
    component: PreferredSizeComponent
  },
  {
    path:'purpose-of-purchase',
    component: PurposeOfPurchaseComponent
  },
  {
    path:'project',
    component: ProjectComponent
   },
  {
    path:'proj-user-mapping',
    component: ProjUserMappingComponent
  },
  {
    path:'status',
    component: StatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }
