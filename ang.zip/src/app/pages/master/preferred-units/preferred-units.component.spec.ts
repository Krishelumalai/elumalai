import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferredUnitsComponent } from './preferred-units.component';

describe('PreferredUnitsComponent', () => {
  let component: PreferredUnitsComponent;
  let fixture: ComponentFixture<PreferredUnitsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreferredUnitsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreferredUnitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
