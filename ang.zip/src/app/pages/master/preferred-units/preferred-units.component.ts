import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { DataSource } from 'src/app/shared/models/DataSource';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-preferred-units',
  templateUrl: './preferred-units.component.html',
  styleUrls: ['./preferred-units.component.scss']
})
export class PreferredUnitsComponent {
  showTable = true;
  preferredUnitForm!: FormGroup;

  preferredUnitList = [
    {
      "preferredunitID": 1,
      "name": "<50 L",
      "description": " "
    }
  ]
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initPreferredUnitForm();
    this.getPreferredUnitList();
  }


  initPreferredUnitForm() {
    this.preferredUnitForm = this.fb.group({
      unitId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getPreferredUnitList() {
    this.masterService.getPreferredUnitList().subscribe((data: any) => {
      this.preferredUnitList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.preferredUnitList));
    })
  }

  get isEdit() {
    return this.preferredUnitForm.controls['unitId'].value !== 0;
  }

  savePreferredUnitDetail() {
    if (this.preferredUnitForm.valid) {
      this.masterService
        .savePreferredUnitDetail(this.preferredUnitForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getPreferredUnitList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Preferred Unit added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Preferred Unit updated successfully',
                Messages.SUCCESS
              );
            this.preferredUnitForm.reset();
          }
        });
    } else {
      this.preferredUnitForm.markAllAsTouched();
    }
  }
 

  pageChanged(event: any[]) {
    this.preferredUnitList = event; 
  }

  editData(obj: any) {
    this.preferredUnitForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.preferredUnitForm.reset();
  }

  reset() {
    this.preferredUnitForm.reset();
  }
  }