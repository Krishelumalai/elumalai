import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-occupation',
  templateUrl: './occupation.component.html',
  styleUrls: ['./occupation.component.scss']
})
export class OccupationComponent implements OnInit {
  showTable = true;
  occupationForm!: FormGroup;
  occupationList: any[] = [
    {
      "occupationID": 1,
      "name": "Salaried",
      "description": " "
    }
  ]
dataSource: any[] = [];
  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initOccupationForm();
    this.getOccupationList();
  }

  initOccupationForm() {
    this.occupationForm = this.fb.group({
      occupationId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getOccupationList() {
    this.masterService.getOccupationList().subscribe((data: any) => {
      this.occupationList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.occupationList));
    }
    )
  }

  get isEdit() {
    return this.occupationForm.controls['occupationId'].value !== 0;
  }

  saveOccupationDetail() {
    if (this.occupationForm.valid) {
      this.masterService
        .saveOccupationDetail(this.occupationForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getOccupationList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Occupation added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Occupation updated successfully',
                Messages.SUCCESS
              );
            this.occupationForm.reset();
          }
        });
    } else {
      this.occupationForm.markAllAsTouched();
    }
  }

  pageChanged(event: any[]) {
    this.occupationList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.occupationForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.occupationForm.reset();
  }

  reset() {
    this.occupationForm.reset();
  }

}
