import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferredBudgetRangeComponent } from './preferred-budget-range.component';

describe('PreferredBudgetRangeComponent', () => {
  let component: PreferredBudgetRangeComponent;
  let fixture: ComponentFixture<PreferredBudgetRangeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreferredBudgetRangeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreferredBudgetRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
