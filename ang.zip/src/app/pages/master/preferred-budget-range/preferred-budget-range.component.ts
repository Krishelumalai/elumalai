import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-preferred-budget-range',
  templateUrl: './preferred-budget-range.component.html',
  styleUrls: ['./preferred-budget-range.component.scss']
})
export class PreferredBudgetRangeComponent {

  showTable = true;
  preferredBudgetRangeForm!: FormGroup;

  preferredBudgetRangeList = [
    {
      "preferredBudgetRangeID": 1,
      "name": "<50 L",
      "description": " "
    }
  ]
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initPreferredBudgetRangeForm();
    this.getPreferredBudgetRangeList();
  }


  initPreferredBudgetRangeForm() {
    this.preferredBudgetRangeForm = this.fb.group({
      budgetId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getPreferredBudgetRangeList() {
    this.masterService.getPreferredBudgetRangeList().subscribe((data: any) => {
      this.preferredBudgetRangeList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.preferredBudgetRangeList));
    })
  }

  get isEdit() {
    return this.preferredBudgetRangeForm.controls['budgetId'].value !== 0;
  }

  savePreferredBudgetRangeDetail() {
    if (this.preferredBudgetRangeForm.valid) {
      this.masterService
        .savePreferredBudgetRangeDetail(this.preferredBudgetRangeForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getPreferredBudgetRangeList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Preferred Budget Range added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Preferred Budget Range updated successfully',
                Messages.SUCCESS
              );
            this.preferredBudgetRangeForm.reset();
          }
        });
    } else {
      this.preferredBudgetRangeForm.markAllAsTouched();
    }
  }

  savePreferredBudgetRangeForm() {
    if(this.preferredBudgetRangeForm.valid){
    this.masterService.savePreferredBudgetRangeDetail(this.preferredBudgetRangeForm.value).subscribe((data: any) => {
      if (data) {
        this.getPreferredBudgetRangeList();
        this.showTable = true;
        !this.isEdit
          ? this.commonService.showMessage(
            'Budget range added successfully',
            Messages.SUCCESS
          )
          : this.commonService.showMessage(
            'Budget range updated successfully',
            Messages.SUCCESS
          );
        this.preferredBudgetRangeForm.reset();
      }
    })
    } else {
      this.preferredBudgetRangeForm.markAllAsTouched();
    }
  }

  pageChanged(event: any[]) {
    this.preferredBudgetRangeList = event; 
  }

  editData(obj: any) {
    this.preferredBudgetRangeForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.preferredBudgetRangeForm.reset();
  }

  reset() {
    this.preferredBudgetRangeForm.reset();
  }


}
