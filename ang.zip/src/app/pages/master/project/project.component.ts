import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent {
  showTable = true;
  projectForm!: FormGroup;

  projectList = [
    {
      "projectID": 1,
      "name": "<50 L",
      "description": " "
    }
  ]
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initProjectForm();
    this.getProjectList();
  }


  initProjectForm() {
    this.projectForm = this.fb.group({
      intProjId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getProjectList() {
    this.masterService.getProjectList().subscribe((data: any) => {
      this.projectList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.projectList));
    })
  }

  get isEdit() {
    return this.projectForm.controls['intProjId'].value !== 0;
  }

  saveProjectDetail() {
    if (this.projectForm.valid) {
      this.masterService
        .saveProjectDetail(this.projectForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getProjectList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Project added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Project updated successfully',
                Messages.SUCCESS
              );
            this.projectForm.reset();
          }
        });
    } else {
      this.projectForm.markAllAsTouched();
    }
  }
 

  pageChanged(event: any[]) {
    this.projectList = event; 
  }

  editData(obj: any) {
    this.projectForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.projectForm.reset();
  }

  reset() {
    this.projectForm.reset();
  }
}
