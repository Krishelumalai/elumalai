import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { DataSource } from 'src/app/shared/models/DataSource';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-age',
  templateUrl: './age.component.html',
  styleUrls: ['./age.component.scss'],
})
export class AgeComponent implements OnInit {
  showTable: boolean = true;
  ageForm!: FormGroup;
  ageList: any[] = [ 
  ];
dataSource: any[] = [];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initAgeForm();
    this.getAgeList();
  }

  initAgeForm() {
    this.ageForm = this.fb.group({
      ageId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }
  getAgeList() {
    this.masterService.getAgeList().subscribe((data: any) => {
      this.ageList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.ageList)); 
    });
  }

  get isEdit() {
    return this.ageForm.controls['ageId'].value !== 0;
  }

  saveAgeDetail() {
    if (this.ageForm.valid) {
      this.masterService
        .saveAgeDetail(this.ageForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getAgeList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                  'Age added successfully',
                  Messages.SUCCESS
                )
              : this.commonService.showMessage(
                  'Age updated successfully',
                  Messages.SUCCESS
                );
            this.ageForm.reset();
          }
        });
    } else {
      this.ageForm.markAllAsTouched();
    }
  }
  pageChanged(event: any[]) {
    this.ageList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.ageForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.ageForm.reset();
  }

  reset() {
    this.ageForm.reset();
  }
}
