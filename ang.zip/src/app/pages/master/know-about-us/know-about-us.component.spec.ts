import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnowAboutUsComponent } from './know-about-us.component';

describe('KnowAboutUsComponent', () => {
  let component: KnowAboutUsComponent;
  let fixture: ComponentFixture<KnowAboutUsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnowAboutUsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnowAboutUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
