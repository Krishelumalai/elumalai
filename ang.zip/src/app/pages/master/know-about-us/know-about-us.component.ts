import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { DataSource } from 'src/app/shared/models/DataSource';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-know-about-us',
  templateUrl: './know-about-us.component.html',
  styleUrls: ['./know-about-us.component.scss']
})
export class KnowAboutUsComponent implements OnInit {
  showTable = true;
  knowAboutUsForm!: FormGroup;
  knowAboutUsList: any[] = [
    {
      "knowAboutUsID": 1,
      "name": "Newspaper",
      "description": " ",
    },
  ];
  dataSource: any[]=[];
  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initKnowAboutUsForm();
    this.getKnowAboutUsList();
  }

  initKnowAboutUsForm() {
    this.knowAboutUsForm = this.fb.group({
      aboutusId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getKnowAboutUsList() {
    this.masterService.getKnowAboutUsList().subscribe((data: any) => {
      this.knowAboutUsList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.knowAboutUsList)); 
    }
    )
  }

  get isEdit() {
    return this.knowAboutUsForm.controls['aboutusId'].value !== 0;
  }

  saveKnowAboutUsDetail() {
    if (this.knowAboutUsForm.valid) {
      this.masterService
        .saveKnowAboutUsDetail(this.knowAboutUsForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getKnowAboutUsList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Know About Us added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Know About Us updated successfully',
                Messages.SUCCESS
              );
            this.knowAboutUsForm.reset();
          }
        });
    } else {
      this.knowAboutUsForm.markAllAsTouched();
    }
  }

  pageChanged(event: any[]) {
    this.knowAboutUsList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.knowAboutUsForm.patchValue(obj);
    this.showTable = false;
  }


  cancel() {
    this.showTable = true;
    this.knowAboutUsForm.reset();
  }

  reset() {
    this.knowAboutUsForm.reset()
  }

}
