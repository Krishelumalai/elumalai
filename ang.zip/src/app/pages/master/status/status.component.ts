import {ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  NonNullableFormBuilder,
  Validators,
} from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.scss']
})
export class StatusComponent {

  showTable: boolean = true;
  statusForm!: FormGroup;
  statusList: any[] = [ 
  ];
dataSource: any[] = [];


  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initStatusForm();
    this.getStatusList();
  }

  initStatusForm() {
    this.statusForm = this.fb.group({
      statusId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
    });
  }
  getStatusList() {
    this.masterService.getStatusList().subscribe((data: any) => {
      this.statusList = data;
    });
  }

  get isEdit() {
    return this.statusForm.controls['statusId'].value !== 0;
  }

  saveStatusDetail() {
    if (this.statusForm.valid) {
      this.masterService
        .saveStatusDetail(this.statusForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getStatusList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                  'Status added successfully',
                  Messages.SUCCESS
                )
              : this.commonService.showMessage(
                  'Status updated successfully',
                  Messages.SUCCESS
                );
            this.statusForm.reset();
          }
        });
    } else {
      this.statusForm.markAllAsTouched();
    }
  }
  pageChanged(event: any[]) {
    this.statusList = event;
    this.cdr.detectChanges();
  }

  editData(obj: any) {
    this.statusForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.statusForm.reset();
  }

  reset() {
    this.statusForm.reset();
  }

}
