import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferredSizeComponent } from './preferred-size.component';

describe('PreferredSizeComponent', () => {
  let component: PreferredSizeComponent;
  let fixture: ComponentFixture<PreferredSizeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreferredSizeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreferredSizeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
