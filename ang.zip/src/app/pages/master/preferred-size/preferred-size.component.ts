import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NonNullableFormBuilder, Validators } from '@angular/forms';
import { Messages } from 'src/app/shared/messages.enum';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-preferred-size',
  templateUrl: './preferred-size.component.html',
  styleUrls: ['./preferred-size.component.scss']
})
export class PreferredSizeComponent implements OnInit {
  
  showTable = true;
  preferredSizeForm!: FormGroup;

  preferredSizeList = [
    {
      "preferredSizeID": 1,
      "name": "<50 L",
      "description": " "
    }
  ]
  dataSource: any[]=[];

  constructor(
    private fb: NonNullableFormBuilder,
    private commonService: CommonService,
    private masterService: MasterService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initPreferredSizeForm();
    this.getPreferredSizeList();
  }


  initPreferredSizeForm() {
    this.preferredSizeForm = this.fb.group({
      sizeId: new FormControl<number>(0, { nonNullable: true }),
      name: new FormControl<string>('', Validators.required),
      description: new FormControl<string>('', { nonNullable: true }),
      active: new FormControl<boolean>(true, { nonNullable: true }),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }

  getPreferredSizeList() {
    this.masterService.getPreferredSizeList().subscribe((data: any) => {
      this.preferredSizeList = data; 
      this.dataSource = JSON.parse(JSON.stringify(this.preferredSizeList));
    })
  }

  get isEdit() {
    return this.preferredSizeForm.controls['sizeId'].value !== 0;
  }

  savePreferredSizeDetail() {
    if (this.preferredSizeForm.valid) {
      this.masterService
        .savePreferredSizeDetail(this.preferredSizeForm.value)
        .subscribe((data: any) => {
          if (data) {
            this.getPreferredSizeList();
            this.showTable = true;
            !this.isEdit
              ? this.commonService.showMessage(
                'Preferred size added successfully',
                Messages.SUCCESS
              )
              : this.commonService.showMessage(
                'Preferred size updated successfully',
                Messages.SUCCESS
              );
            this.preferredSizeForm.reset();
          }
        });
    } else {
      this.preferredSizeForm.markAllAsTouched();
    }
  }
 

  pageChanged(event: any[]) {
    this.preferredSizeList = event; 
  }

  editData(obj: any) {
    this.preferredSizeForm.patchValue(obj);
    this.showTable = false;
  }
  cancel() {
    this.showTable = true;
    this.preferredSizeForm.reset();
  }

  reset() {
    this.preferredSizeForm.reset();
  }
}