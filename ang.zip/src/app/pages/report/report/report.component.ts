import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { map, Observable, startWith } from 'rxjs';
import { MasterService } from 'src/app/shared/services/master.service';
import * as XLSX from 'xlsx';
type AOA = any[][];
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss'],
  providers: [DatePipe]
})
export class ReportComponent implements OnInit {
  @ViewChild('table') table!: ElementRef;
  showTable = true;
  reportList: any[] = [];
  dataSource: any;
  ToDate: any;
  FromDate: any;
  filteredProjectData: any[]=[];
  public selectedValues: string[] = [];
  public filterLogs: any = [];
  public logList: any[] = [];
  public wisetype: string = '';
  public checkedList: any[] = [];
  Projectdata: any[] = [];
  dropSearchText:string = '';
  showDropDown!: boolean;

  constructor(private masterService: MasterService, private datePipe: DatePipe) { }
  


  ngOnInit() {
    this.getProjectList();
  }

  getProjectList() {
    this.masterService.getProjectList().subscribe((data: any) => {
      this.Projectdata = data;
      this.filteredProjectData = JSON.parse(JSON.stringify(this.Projectdata));
    })
  }

  getCustomerList() {
    const projIds:number[] = [];
    if(this.wisetype == 'Projectwise'){
      this.checkedList.forEach((element: any) => {
        this.Projectdata.forEach((item: any) => {
          if (item.name == element) {
            projIds.push(item.intProjId);
          }
        });
      });
    }
    var data = {
      "startDate": this.wisetype == 'Projectwise' ? null : new Date(this.datePipe.transform(this.FromDate, 'yyyy-MM-dd') || ''),
      "endDate": this.wisetype == 'Projectwise' ? null : new Date(this.datePipe.transform(this.ToDate, 'yyyy-MM-dd') || ''),
      "reportType": this.wisetype == 'Projectwise' ? "Project" : "Date",
      "projectId": this.wisetype == 'Projectwise' ? projIds : []
    }
    this.masterService.getCustomerReport(data).subscribe((data: any) => {
      this.reportList = data;
      this.dataSource = JSON.parse(JSON.stringify(this.reportList));
    })
  }

  setParams(value: any) {
    if (value) {
      this.filterLogs = value;
      this.masterService.getCustomerLogList(value.customerId).subscribe((res: any) => {
        this.logList = res;
      })
    }
  }
  filterData(event:any) {
    this.filteredProjectData = this.Projectdata.filter((item: any) => {
      return item.name.toLowerCase().includes(event.target.value.toLowerCase());
    });
  }

  pageChanged(event: any): void {
    this.reportList = event;
  }

  getSelectedValue(event:any, value: String) {
    if (event.target.checked) {
      this.checkedList.push(value);
    } else {
      var index = this.checkedList.indexOf(value);
      this.checkedList.splice(index, 1);
    }
  }
  clearData() {
    if(this.wisetype == 'Projectwise'){
      this.selectedValues = [];
      this.checkedList = [];
    } else {
      this.FromDate = null;
      this.ToDate = null;
    } 
  }

  export() {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
      this.table.nativeElement
    );
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const xldata = <AOA>XLSX.utils.sheet_to_json(ws, { header: 1 });
    for (let data of xldata) {
      data.splice(0, 1);
    }
    const ws1: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xldata);
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb1, ws1, 'Sheet1');
    XLSX.writeFile(wb1, `Customer_report_${this.datePipe.transform(new Date(),'dd-MM-yy_hh:mm')}.xlsx`);
  }
}
