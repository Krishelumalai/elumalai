import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-acquisition-list',
  templateUrl: './acquisition-list.component.html',
  styleUrls: ['./acquisition-list.component.scss']
})
export class AcquisitionListComponent {

  public showTable = true;
  public greForm!: FormGroup;

  // acquisitionList:any[] =[];
  acquisitionList: any[] = [];
  dataSource: any[] = [];
  public flsList: any[] = [];
  public flsTlList: any[] = [];
  public svcList: any[] = [];
  public svcTlList: any[] = [];
  public statusList: any[] = [];
  @ViewChild('closebutton') closebutton:any;
  adminEditFlag: boolean =false;
  editDetail: any;
  searchText:string='';
  user: any;


  constructor(private masterService: MasterService, private fb: FormBuilder) { }

  ngOnInit(): void {

    this.user = JSON.parse(localStorage.getItem('user') || '{}');
    this.initGreForm();
    this.getCustomerList();
    this.getStatusList();
    this.getFLSList();
    this.getFLSTLList();
    this.getSVCList();
    this.getSVCTLList();
    this.dataSource = JSON.parse(JSON.stringify(this.acquisitionList));
  }

  initGreForm(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.greForm = new FormGroup({
      customerId: new FormControl<number | null>(null, { nonNullable: false, validators: Validators.required }),
      leadId: new FormControl<string>('', Validators.required),
      statusId: new FormControl<string | null>(null, { nonNullable: false, validators: Validators.required }),
      flsid: new FormControl<string | null>(null, { nonNullable: false, validators: Validators.required }),
      flstlid: new FormControl<string | null>(null, { nonNullable: false, validators: Validators.required }),
      svcid: new FormControl<string | null>(null, { nonNullable: false, validators: Validators.required }),
      svctlid: new FormControl<string | null>(null, { nonNullable: false, validators: Validators.required }),
      remarks: new FormControl<string>(''),
      loggedIn: new FormControl<number>(user.userId, { nonNullable: true }),
    });
  }

  getCustomerList() {

    this.masterService.getCustomerList(this.user.userId).subscribe((data: any) => {
      if(this.user.roleId == 1) {
      this.acquisitionList = data;
      }
      else{
        this.acquisitionList = data.filter((x:any) => x.formStatus == 'SUBMITTED');
      }
      this.dataSource = JSON.parse(JSON.stringify(this.acquisitionList));
    })
  }
  pageChanged(event: any) {
    this.acquisitionList = event;
  }

  getFLSList(): void {
    this.masterService.getFLSList().subscribe((res: any) => {
      this.flsList = res;
    });
  }

  getSVCTLList(): void {
    this.masterService.getSVCTlList().subscribe((res: any) => {
      this.svcTlList = res;
    });
  }
  getFLSTLList(): void {
    this.masterService.getFLSTlList().subscribe((res: any) => {
      this.flsTlList = res;
    });
  }

  getSVCList(): void {
    this.masterService.getSVCList().subscribe((res: any) => {
      this.svcList = res;
    });
  }

  getStatusList(): void {
    this.masterService.getStatusList().subscribe((res: any) => {
      this.statusList = res;
    });
  }

  setParams(value: number) {
    if (value) {
      this.greForm.reset();
      this.greForm.get('customerId')?.setValue(value);
    }
  }
  filterData(){
    // this.acquisitionList = this.dataSource.filter((x:any) => x.leadId.toLowerCase().includes(this.searchText.toLowerCase()));

  }

  reset() {
    let customerID = this.greForm.get('customerId')?.value;
    this.greForm.reset();
    this.greForm.get('customerId')?.setValue(customerID);
  }

  acquisitionSave() {
    if (this.greForm.valid) {  
      this.masterService.saveGreFormDetail(this.greForm.value).subscribe((res: any) => {
        this.getCustomerList();

    this.closebutton.nativeElement.click();
        this.reset();
      }
      );
    }
    else{
      this.greForm.markAllAsTouched();
    }
  }

  adminEdit(data:any){
    this.adminEditFlag = true;
    this.editDetail = data;
  }

  backToGrid(){
    this.adminEditFlag=false;
    this.getCustomerList();
  }
}
