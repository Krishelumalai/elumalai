import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { AcquisitionListComponent } from './acquisition-list/acquisition-list.component';
import { AcquisitionRegisterComponent } from './acquisition-register/acquisition-register.component';

const routes: Routes = [

  {
    path: '',
    component: AcquisitionRegisterComponent,
  },

  {
    path: 'acquisition-register',
    canActivate:[AuthGuard],
    component: AcquisitionRegisterComponent,
  },
  {
    path: 'acquisitionlist',
    canActivate:[AuthGuard],
    component: AcquisitionListComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AcquisitionRoutingModule { }
