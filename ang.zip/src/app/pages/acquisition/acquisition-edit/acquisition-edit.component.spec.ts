import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcquisitionEditComponent } from './acquisition-edit.component';

describe('AcquisitionEditComponent', () => {
  let component: AcquisitionEditComponent;
  let fixture: ComponentFixture<AcquisitionEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcquisitionEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AcquisitionEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
