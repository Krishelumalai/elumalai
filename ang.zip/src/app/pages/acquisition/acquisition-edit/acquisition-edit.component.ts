import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormControl,
  FormGroup,
  UntypedFormBuilder,
  Validators,
} from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';
@Component({
  selector: 'app-acquisition-edit',
  templateUrl: './acquisition-edit.component.html',
  styleUrls: ['./acquisition-edit.component.scss'],
})
export class AcquisitionEditComponent implements OnInit {
  @Input() editDetail: any;
  acquisitionForm!: FormGroup;
  greForm!: FormGroup;
  sizeList: any[] = [];
  budgetList: any[] = [];
  unitList: any[] = [];
  purposeList: any[] = [];
  aboutUsList: any[] = [];
  ageList: any[] = [];
  occupationList: any[] = [];
  projectList: any[] = [];
  public flsList: any[] = [];
  public flsTlList: any[] = [];
  public svcList: any[] = [];
  public svcTlList: any[] = [];
  public statusList: any[] = [];
  @Output() backToGrid: EventEmitter<any> = new EventEmitter<any>();
  user: any;
  constructor(
    private fb: UntypedFormBuilder,
    private masterService: MasterService,
    private commonService: CommonService
  ) {}

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('user') || '{}');
    this.initCustomerForm();
    this.initGREForm();
    this.getAgeList();
    this.getOccupationList();
    this.getSizeList();
    this.getBudgetList();
    this.getUnitList();
    this.getPurposeList();
    this.getAboutUsList();
    this.getProjectList();
    this.getStatusList();
    this.getFLSList();
    this.getFLSTLList();
    this.getSVCList();
    this.getSVCTLList();
    setTimeout(() => {
      this.acquisitionForm.patchValue(this.editDetail);
      this.greForm.patchValue(this.editDetail.gre);
    }, 0);
  }
  initCustomerForm() {
    this.acquisitionForm = this.fb.group({
      customerId: new FormControl<number | null>(null),
      customerName: new FormControl<string | null>(null, Validators.required),
      currentResidenceArea: new FormControl<string | null>(
        null,
        Validators.required
      ),
      contactNumber: new FormControl<number | null>(null, Validators.required),
      alternateNumber: new FormControl<string | null>('', Validators.required),
      emailId: new FormControl<string | null>(null, Validators.required),
      unitId: new FormControl<null | number>(null, Validators.required),
      budgetId: new FormControl<null | number>(null, Validators.required),
      aboutUsId: new FormControl<null | number>(null, Validators.required),
      intProjId: new FormControl<null | number>(null, Validators.required),
      ageId: new FormControl<number | null>(null),
      sizeId: new FormControl<null | number>(null),
      occupationId: new FormControl<number | null>(null),
      purposeId: new FormControl<null | number>(null),
      active: new FormControl(true),
      receiveUpdate: new FormControl(false),
      loggedIn: new FormControl<number>(1, { nonNullable: true }),
    });
  }
  initGREForm() {
    this.greForm = new FormGroup({
      greformId: new FormControl<number | null>(null),
      customerId: new FormControl<number | null>(this.editDetail.customerId, {
        nonNullable: false,
        validators: Validators.required,
      }),
      leadId: new FormControl<string>('', Validators.required),
      statusId: new FormControl<string | null>(null, {
        nonNullable: false,
        validators: Validators.required,
      }),
      flsid: new FormControl<string | null>(null, {
        nonNullable: false,
        validators: Validators.required,
      }),
      flstlid: new FormControl<string | null>(null, {
        nonNullable: false,
        validators: Validators.required,
      }),
      svcid: new FormControl<string | null>(null, {
        nonNullable: false,
        validators: Validators.required,
      }),
      svctlid: new FormControl<string | null>(null, {
        nonNullable: false,
        validators: Validators.required,
      }),
      remarks: new FormControl<string>(''),
      loggedIn: new FormControl<number>(this.user.userId, {
        nonNullable: true,
      }),
    });
  }

  getUnitList(): void {
    this.masterService.getPreferredUnitList().subscribe((res: any) => {
      this.unitList = res;
    });
  }

  getBudgetList(): void {
    this.masterService.getPreferredBudgetRangeList().subscribe((res: any) => {
      this.budgetList = res;
    });
  }
  getAboutUsList(): void {
    this.masterService.getKnowAboutUsList().subscribe((res: any) => {
      this.aboutUsList = res;
    });
  }

  getAgeList(): void {
    this.masterService.getAgeList().subscribe((res: any) => {
      this.ageList = res;
    });
  }

  getOccupationList(): void {
    this.masterService.getOccupationList().subscribe((res: any) => {
      this.occupationList = res;
    });
  }

  getPurposeList(): void {
    this.masterService.getPurposeOfPurchaseList().subscribe((res: any) => {
      this.purposeList = res;
    });
  }

  getSizeList(): void {
    this.masterService.getPreferredSizeList().subscribe((res: any) => {
      this.sizeList = res;
    });
  }

  getProjectList(): void {
    this.masterService.getProjectList().subscribe((res: any) => {
      this.projectList = res;
    });
  }

  getFLSList(): void {
    this.masterService.getFLSList().subscribe((res: any) => {
      this.flsList = res;
    });
  }

  getSVCTLList(): void {
    this.masterService.getSVCTlList().subscribe((res: any) => {
      this.svcTlList = res;
    });
  }
  getFLSTLList(): void {
    this.masterService.getFLSTlList().subscribe((res: any) => {
      this.flsTlList = res;
    });
  }

  getSVCList(): void {
    this.masterService.getSVCList().subscribe((res: any) => {
      this.svcList = res;
    });
  }

  getStatusList(): void {
    this.masterService.getStatusList().subscribe((res: any) => {
      this.statusList = res;
    });
  }
  updateCustomerDetail() {
    if (this.acquisitionForm.valid) {
      this.acquisitionForm.get('loggedIn')?.setValue(this.user.userId);
      this.masterService
        .saveCustomerDetail(this.acquisitionForm.value)
        .subscribe((res: any) => {
          this.commonService.showMessage(
            'Customer detail updated successfully',
            'success'
          );
          this.back();
        });
    } else {
      this.acquisitionForm.markAllAsTouched();
    }
  }
  updateGreDetail() {
    if (this.greForm.valid) {
      this.greForm.get('loggedIn')?.setValue(this.user.userId);
      this.greForm.get('customerId')?.setValue(this.editDetail.customerId);
      this.masterService
        .saveGreFormDetail(this.greForm.value)
        .subscribe((res: any) => {
          this.commonService.showMessage(
            'GRE detail updated successfully',
            'success'
          );
          this.back();
        });
    } else {
      this.greForm.markAllAsTouched();
    }
  }
  reset() {}
  back() {
    this.backToGrid.emit();
  }
}
