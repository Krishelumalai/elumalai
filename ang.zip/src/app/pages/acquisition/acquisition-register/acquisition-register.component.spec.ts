import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcquisitionRegisterComponent } from './acquisition-register.component';

describe('AcquisitionRegisterComponent', () => {
  let component: AcquisitionRegisterComponent;
  let fixture: ComponentFixture<AcquisitionRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcquisitionRegisterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AcquisitionRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
