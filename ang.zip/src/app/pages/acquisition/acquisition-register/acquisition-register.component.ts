import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';
import { Status } from 'src/app/shared/status.enum';

@Component({
  selector: 'app-acquisition-register',
  templateUrl: './acquisition-register.component.html',
  styleUrls: ['./acquisition-register.component.scss'],
})
export class AcquisitionRegisterComponent implements OnInit {
  acquisitionForm!: FormGroup;

  pageNumber: number = 1;

  projectList: any[] = [];
  ageList: any[] = [{
    ageId: 1, name: '<25'
  }];
  occupationList: any[] = [{
    occupationId: 1, name: 'Salaried'
  }];
  sizeList: any[] = [];
  budgetList: any[] = [];
  unitList: any[] = [];
  purposeList: any[] = [];
  aboutUsList: any[] = [];
  constructor(private fb: FormBuilder, private masterService: MasterService,
    private commonService: CommonService, private router: Router) { }

  ngOnInit(): void {
    this.initAcquisitionFormRegisterForm();
    this.getAgeList();
    this.getOccupationList();
    this.getSizeList();
    this.getBudgetList();
    this.getUnitList();
    this.getPurposeList();
    this.getAboutUsList();
    this.getProjectList();
  }


  initAcquisitionFormRegisterForm(): void {
    this.acquisitionForm = this.fb.group({
      contactForm: this.fb.group({
        customerName: new FormControl<string | null>(null, Validators.required),
        currentResidenceArea: new FormControl<string | null>(null, Validators.required),
        contactNumber: new FormControl<number | null>(
          null,
          Validators.required
        ),
        alternateNumber: new FormControl<string | null>(''),
        emailId: new FormControl<string | null>(null, Validators.required),
        unitId: new FormControl<null | number>(null, Validators.required ),
        budgetId: new FormControl<null | number>(null, Validators.required),
        aboutUsId: new FormControl<null | number>(null, Validators.required),
        intProjId: new FormControl<null | number>(null, Validators.required), 
      }),

      preferredForm: this.fb.group({      
        ageId: new FormControl<number | null>(null),
        sizeId: new FormControl<null | number>(null),
        occupationId: new FormControl<number | null>(null),
        purposeId: new FormControl<null | number>(null),   
        receiveUpdate: new FormControl<null | boolean>(false),
        active: new FormControl(true),
      }),
    });
  }

  getAgeList(): void {
    this.masterService.getAgeList().subscribe((res: any) => {
      this.ageList = res;
    });
  }

  getOccupationList(): void {
    this.masterService.getOccupationList().subscribe((res: any) => {
      this.occupationList = res;
    });
  }

  getSizeList(): void {
    this.masterService.getPreferredSizeList().subscribe((res: any) => {
      this.sizeList = res;
    });
  }

  getBudgetList(): void {
    this.masterService.getPreferredBudgetRangeList().subscribe((res: any) => {
      this.budgetList = res;
    });
  }

  getUnitList(): void {
    this.masterService.getPreferredUnitList().subscribe((res: any) => {
      this.unitList = res;
    });
  }

  getPurposeList(): void {
    this.masterService.getPurposeOfPurchaseList().subscribe((res: any) => {
      this.purposeList = res;
    });
  }

  getAboutUsList(): void {
    this.masterService.getKnowAboutUsList().subscribe((res: any) => {
      this.aboutUsList = res;
    });
  }

  getProjectList(): void {
    this.masterService.getProjectList().subscribe((res: any) => {
      this.projectList = res;
    });
  }


  get f() {
    return this.acquisitionForm.controls;
  }

  next(formName: string) {
    if (this.f[formName].valid) {
      formName !== 'preferredForm'
        ? (this.pageNumber = this.pageNumber + 1)
        : this.submitAcquisitionForm();
      return;
    }
    this.f[formName].markAllAsTouched();
  }
  back(): void {
    this.pageNumber == 1
      ? window.open('https://www.casagrand.co.in/', '_self')
      : (this.pageNumber = this.pageNumber - 1);
  }

  submitAcquisitionForm(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    let obj = {
      customerId:0,
      customerName: this.f['contactForm'].get('customerName')?.value,
      currentResidenceArea: this.f['contactForm'].get('currentResidenceArea')?.value,
      contactNumber: this.f['contactForm'].get('contactNumber')?.value,
      alternateNumber: this.f['contactForm'].get('alternateNumber')?.value,
      emailId: this.f['contactForm'].get('emailId')?.value,
      aboutUsId: +this.f['contactForm'].get('aboutUsId')?.value,
      unitId: +this.f['contactForm'].get('unitId')?.value,
      budgetId: +this.f['contactForm'].get('budgetId')?.value,

      ageId:this.f['preferredForm'].get('ageId')?.value?+this.f['preferredForm'].get('ageId')?.value:null,
      occupationId: this.f['preferredForm'].get('occupationId')?.value?+this.f['preferredForm'].get('occupationId')?.value:null,
      intProjId: +this.f['contactForm'].get('intProjId')?.value,     
      sizeId: this.f['preferredForm'].get('sizeId')?.value? +this.f['preferredForm'].get('sizeId')?.value:null,
      purposeId: this.f['preferredForm'].get('purposeId')?.value? +this.f['preferredForm'].get('purposeId')?.value:null,
      active: this.f['preferredForm'].get('active')?.value,
      receiveUpdate: this.f['preferredForm'].get('receiveUpdate')?.value,
      loggedIn: (user && user.userId)? user.userId:null,
      formStatus: Status.SUBMITTED 
    };
    this.masterService.saveCustomerDetail(obj).subscribe((res: any) => { 
      this.commonService.showMessage('Thank you for your interest in CasaGrand. We will get in touch with you shortly.','success');
      window.open('https://www.casagrand.co.in/', '_self')
    });
  }

}
