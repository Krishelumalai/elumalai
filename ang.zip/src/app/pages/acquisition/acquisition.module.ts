import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AcquisitionRoutingModule } from './acquisition-routing.module';
import { AcquisitionListComponent } from './acquisition-list/acquisition-list.component';
import { AcquisitionRegisterComponent } from './acquisition-register/acquisition-register.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { AcquisitionEditComponent } from './acquisition-edit/acquisition-edit.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    AcquisitionListComponent,
    AcquisitionRegisterComponent,
    AcquisitionEditComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AcquisitionRoutingModule,
    SharedModule,
    Ng2SearchPipeModule
  ]
})
export class AcquisitionModule { }
