import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {
  menuList :any[]= [];
  userDetails: any;

  
  constructor( private router:Router,private masterService:MasterService,private commonService:CommonService) { }

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('user')!);
    this.getMenuList()
  }
  getMenuList(){
    this.commonService.originalMenuList$.subscribe((res:any)=>{
      this.menuList =res;
    });
  }

  navigateTo(route:any){
if(route){
   this.router.navigate([`nav/${route}`]);
}
  }
   isArrow(menu:any){
    return menu.route!==''?'collapsed':'expanded'
  }
  logOut(){ 
    this.router.navigate(['/']);
  }
}
