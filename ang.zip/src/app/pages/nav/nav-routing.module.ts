import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SidenavComponent } from './sidenav/sidenav.component';

const routes: Routes = [
  {
    path: '',
    component:SidenavComponent,
    children:[
      {
        path:'dashboard',
        loadChildren: () => import('../dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path:'master',
        loadChildren: () => import('../master/master.module').then(m => m.MasterModule)
      },
      {
        path:'user-config',
        loadChildren: () => import('../user/user.module').then(m => m.UserModule)
      },
      {
        path:'acquisition',
        loadChildren: () => import('../acquisition/acquisition.module').then(m => m.AcquisitionModule)
      },
      {
        path:'report',
        loadChildren: () => import('../report/report.module').then(m => m.ReportModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NavRoutingModule { }
