import { Component, OnInit } from '@angular/core';
import { MasterService } from 'src/app/shared/services/master.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dashData: any;

  constructor(private masterService:MasterService) { }

  ngOnInit(): void {
    this.getDashboardData();
  }

  getDashboardData(){
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.masterService.getDashboardCount(user.userId).subscribe((data:any)=>{
      this.dashData = data; 
    })
  }

}
