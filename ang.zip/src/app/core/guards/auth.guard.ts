import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router,private commonService:CommonService) { };
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const userDetails = localStorage.getItem("user") || '';
    if (userDetails != "") { 
        if(this.commonService.menuList.length>0){ 
          const menu = this.commonService.menuList.filter((item:any)=>state.url.includes(item.route));
          if(menu.length==0){
            this.router.navigate(['/unauthorized']);
          }
        } 
      return true;
    } else {
      this.router.navigate(['/'])
      return false;
    }
  }

}
