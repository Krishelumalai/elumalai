import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  menuList:any[]=[];
  originalMenuList$ = new BehaviorSubject<any>([]);
  

  constructor(private toastrService: ToastrService) { }

 public showMessage(message: string, type: string) {
    if(type=='success'){
      this.toastrService.success(message); 
    } else if(type==='error'){
      this.toastrService.error(message);
    }
  } 

  public showInfo(message:any): void {
    this.toastrService.info(message);
  }

  public showWarning(message:any): void {
    this.toastrService.warning(message);
  } 
  setMenuList(menuList: any[]) {
    const flattenMenu:any[] =[];
     menuList.forEach((menu) => {
      if (menu.children.length > 0) {
        menu.children.forEach((child: any) => {
          flattenMenu.push({
            screenId: child.subMenuId,
            screenName: child.menuName,
            route:child.route,
          });
        });
      }
    });
    this.menuList = flattenMenu;
  }
}
