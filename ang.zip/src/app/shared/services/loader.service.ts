import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  showLoader: boolean = false;
  public status: Subject<boolean> = new Subject();
  private _active = false;

  public get active(): boolean {
    return this._active;
  }

  public set active(v: boolean) {
    this._active = v;
    this.status.next(v);
  }
  constructor() {}
  show() {
    this.active = true;
  }
  hide() {
    this.active = false;
  }
}