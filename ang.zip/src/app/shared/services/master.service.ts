import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpConfigService } from './http-config.service';

@Injectable({
  providedIn: 'root',
})
export class MasterService {
  apiUrl: string = environment.apiUrl;
  
  constructor(private http: HttpConfigService) {}
  loggedInUserId(): any{
    const userDetails = localStorage.getItem("user") || '';
    if (userDetails != "") {
      const user = JSON.parse(userDetails);
      return user.userId;
    } else {
      return null;
    }
  }
  authenticateUser(data: any) {
    return this.http.post(`${this.apiUrl}master/authenticate`, data);
  }
  getAgeList() {
    return this.http.get(`${this.apiUrl}master/getAgeList`);
  }
  saveAgeDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveAgeDetail`, data);
  }
  getKnowAboutUsList() {
    return this.http.get(`${this.apiUrl}master/getHowDidYouKnowAboutUSList`);
  }
  saveKnowAboutUsDetail(data: any) {
    return this.http.post(
      `${this.apiUrl}master/saveHowDidYouKnowAboutUSDetail`,
      data
    );
  }
  getOccupationList() {
    return this.http.get(`${this.apiUrl}master/getOccupationList`);
  }
  saveOccupationDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveOccupationDetail`, data);
  }
  getPreferredBudgetRangeList() {
    return this.http.get(`${this.apiUrl}master/getPreferredBudgetRangeList`);
  }
  savePreferredBudgetRangeDetail(data: any) {
    return this.http.post(
      `${this.apiUrl}master/savePreferredBudgetRangeDetail`,
      data
    );
  }
  getPreferredSizeList() {
    return this.http.get(`${this.apiUrl}master/getPreferredSizeList`);
  }
  savePreferredSizeDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/savePreferredSizeDetail`, data);
  }
  getPreferredUnitList() {
    return this.http.get(`${this.apiUrl}master/getPreferredTypeofUnitList`);
  }
  savePreferredUnitDetail(data: any) {
    return this.http.post(
      `${this.apiUrl}master/savePreferredTypeofUnitDetail`,
      data
    );
  }
  getProjectList() {
    return this.http.get(`${this.apiUrl}master/getInterestedProjectNameList`);
  }
  saveProjectDetail(data: any) {
    return this.http.post(
      `${this.apiUrl}master/saveInterestedProjectNameDetail`,
      data
    );
  }
  getPurposeOfPurchaseList() {
    return this.http.get(`${this.apiUrl}master/getPurposeOfPurchaseList`);
  }
  savePurposeOfPurchaseDetail(data: any) {
    return this.http.post(
      `${this.apiUrl}master/savePurposeOfPurchaseDetail`,
      data
    );
  }
  getProjUserMappingList() {
    return this.http.get(`${this.apiUrl}master/getProjUserList`);
  }
  saveProjUserMappingDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveProjUserDetail`, data);
  }

  getStatusList() {
    return this.http.get(`${this.apiUrl}master/getStatusList`);
  }
  saveStatusDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveStatusDetail`, data);
  }

  getUserList() {
    return this.http.get(`${this.apiUrl}master/getUserList`);
  }
  saveUserDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveUserDetail`, data);
  }
  getDepartmentList() {
    return this.http.get(`${this.apiUrl}master/getDepartmentList`);
  }
  saveDepartmentDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveDepartmentDetail`, data);
  }
  getRoleList() {
    return this.http.get(`${this.apiUrl}master/getRoleList`);
  }
  saveRoleDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveRoleDetail`, data);
  }

  getCustomerList(roleId:number) {
    return this.http.get(`${this.apiUrl}master/getCustomerList/${roleId}`);
  }
  saveCustomerDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveCustomerDetail`, data);
  }
  getFLSList() {
    return this.http.get(`${this.apiUrl}master/getFLSList`);
  }
  getFLSTlList() {
    return this.http.get(`${this.apiUrl}master/getFLSTlList`);
  }
  getSVCTlList() {
    return this.http.get(`${this.apiUrl}master/getSVCTlList`);
  }
  getSVCList() {
    return this.http.get(`${this.apiUrl}master/getSVCList`);
  } 
  saveGreFormDetail(data: any) {
    return this.http.post(`${this.apiUrl}master/saveGreFormDetail`, data);
  }
  getCustomerReport(data:any){
    return this.http.post(`${this.apiUrl}master/getCustomerReport`, data);
  }
  getProjectDetails(){
    return this.http.get(`${this.apiUrl}master/getProjectList`);
  }
  getRoleScreenDeatails(roleId: any) {
    return this.http.get(`${this.apiUrl}master/getRoleScreenAccess/${roleId}`);
  }
  saveRoleScreenAccess(data:any){
    return this.http.post(`${this.apiUrl}master/saveRoleScreenAccess`, data);
  }
  getDashboardCount(userId: any) {
    return this.http.get(`${this.apiUrl}master/getDashboardCount/${userId}`);
  }
  getCustomerLogList(customerId: any) {
    return this.http.get(`${this.apiUrl}master/getCustomerLogList/${customerId}`);
  }
  getAllScreensList() {
    return this.http.get(`${this.apiUrl}master/getAllScreensList`);
  }
  getMenuList(roleId:number){
    return this.http.get(`${this.apiUrl}master/getMenuList/${roleId}`);
  }
  checkUser(type: any, value: any) {
    return this.http.get(`${this.apiUrl}master/checkUser/${type}/${value}`);
  }
}
