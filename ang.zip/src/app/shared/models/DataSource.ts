export class DataSource{
    originalData: any[]= [];
    total: number =0;
    filterData: any[]=[];
}