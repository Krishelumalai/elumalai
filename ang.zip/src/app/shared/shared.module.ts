import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationComponent } from './components/pagination/pagination.component';
import { FormsModule } from '@angular/forms';
import { LoaderComponent } from './components/loader/loader.component';
import { NumberOnlyDirective } from './directives/number-only.directive';



@NgModule({
  declarations: [
    PaginationComponent,
    LoaderComponent,
    NumberOnlyDirective
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[PaginationComponent,LoaderComponent,NumberOnlyDirective]
})
export class SharedModule { }
