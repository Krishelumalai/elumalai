import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent  implements OnInit, OnDestroy {
  active: boolean = false;
  subscription!: Subscription;
  constructor(public loader: LoaderService, private cdRef: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.subscription = this.loader.status.subscribe((status: boolean) => {
      this.active = status;
      this.cdRef.detectChanges();
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}