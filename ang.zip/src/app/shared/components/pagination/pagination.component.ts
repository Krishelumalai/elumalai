import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { DataSource } from '../../models/DataSource';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PaginationComponent implements OnInit,OnChanges{
  totalRecords: number = 0;
  pageSize: number = 25;
  offset: number = 1;
  limit: number = 25;
  currentPage: number = 1; 
  @Input() dataSource:any[]=[];
  @Output() pageChanged:EventEmitter<any[]> = new EventEmitter(); 
  finalDataSource: any[]=[];
  initialLimit: number=25;
  constructor(){

  }
  ngOnChanges(changes:SimpleChanges): void { 
    if(changes['dataSource'].currentValue){
    this.finalDataSource = (changes['dataSource'].currentValue);
    this.getPagination();
    }
  }
  ngOnInit(): void {
    this.getPagination();
  }

  getPagination() {
    this.totalRecords = JSON.parse(JSON.stringify(this.finalDataSource.length));
    // this.initialLimit =25;
    this.pageSize = 25;
    this.currentPage = 1;
    // if(this.totalRecords < this.limit){
      // this.limit = this.totalRecords +1;
    // }
    this.updatePage();
  }
  firstPage() {
    this.offset = 1;
    this.limit = 25;
    this.currentPage = 1;
    this.updatePage();
  }
  lastPage() {
    this.currentPage = Math.floor(this.totalRecords / this.pageSize);
    this.offset =  this.currentPage * this.pageSize +1;  
    this.limit = this.totalRecords;
    this.updatePage();
  }
  nextPage() {
    this.offset = +this.limit + 1;
    if (+this.limit + this.pageSize > this.totalRecords) {
      this.limit = this.totalRecords;
    } else {
      this.limit = +this.limit + this.pageSize;
    }
    this.currentPage = + 1;
    this.updatePage();
  }
  prevPage() {
    this.offset = this.offset - this.pageSize;
    if (+this.limit === this.totalRecords) {
      this.limit = Math.floor(+this.limit / this.pageSize)*this.pageSize; 
    } else {
      this.limit = +this.limit - this.pageSize;
    }
    this.currentPage = - 1;
   
    this.updatePage();
  }
  changePageSize(){
    this.currentPage = 1;
    this.offset = 1;
    this.limit = this.pageSize;
    this.updatePage();
  }
  updatePage(){   
    // if(this.finalDataSource.length < this.initialLimit){
    // this.pageChanged.emit( this.finalDataSource.slice(this.offset - 1, this.limit+1)); 
    // } else {
      this.pageChanged.emit( this.finalDataSource.slice(this.offset - 1, +this.limit)); 
    // }
  }
}
