export enum Status {
    // Common Messages
    SUBMITTED = 'SUBMITTED',
    COMPLETED = 'COMPLETED'
}