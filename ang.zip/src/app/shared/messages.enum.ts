export enum Messages {
    // Common Messages
    SUCCESS = 'Success',
    ERROR = 'Error',
    WARNING = 'Warning',
    INFO = 'Info',
}