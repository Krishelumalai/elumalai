import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { CommonService } from './shared/services/common.service';
import { LoaderService } from './shared/services/loader.service';
import { MasterService } from './shared/services/master.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'casagrand-ui';
  active: boolean=false;
  subscription: any;
  constructor(public loader: LoaderService,private cdRef: ChangeDetectorRef,private masterService:MasterService,private commonService:CommonService ){
    this.subscription = this.loader.status.subscribe((status: boolean) => {
      this.active = status;
      this.cdRef.detectChanges();
    });

  }
  ngOnInit(): void {
    const user = JSON.parse(localStorage.getItem('user')!);
    if(user){
      this.masterService.getMenuList(user.roleId).subscribe((res:any)=>{
        this.commonService.originalMenuList$.next(res);
        this.commonService.setMenuList(res);
        })
  }
}
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
