import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { UnauthorizedComponent } from './pages/unauthorized/unauthorized.component';

const routes: Routes = [
  {
    path:'',
    loadChildren: () => import('./pages/auth/auth.module').then(m => m.AuthModule)
  },
  {
    path:'nav',
    canActivate:[AuthGuard],
    loadChildren: () => import('./pages/nav/nav.module').then(m => m.NavModule),
  },
  {
    path:'acquisition',
    loadChildren: () => import('./pages/acquisition/acquisition.module').then(m => m.AcquisitionModule),
  },
  {
    path:'unauthorized',
    component:UnauthorizedComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
