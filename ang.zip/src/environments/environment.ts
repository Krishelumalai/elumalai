export const environment = {
  production: false,
//   apiUrl: 'http://101.53.158.225/Casagrand-server/'
apiUrl: 'https://localhost:7168/'
};